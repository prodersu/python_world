from django.urls import path

from . import views

urlpatterns = [
    path('', views.mydir),
    path('mydir', views.mydir),
    path('send_page', views.send_view),
    path('send', views.send_file),
    path('incoming_page', views.incoming_view),
    path('delete', views.delete_file),
    path('rename', views.rename_file),
]


