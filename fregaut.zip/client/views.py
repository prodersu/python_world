import os

from django.shortcuts import render, redirect
from .models import User, Record
from .forms import *
from .functions import *
from datetime import datetime

dir_path = r'E:\\fregaut\\'


# страница Моя директория
def mydir(request):
    try:
        user = User.objects.get(username=os.getlogin())
        print(user.username)
        filepaths = get_files_list(user.username)
        files = []
        for file_name in filepaths:
            file_size = human_readable_size(os.path.getsize(dir_path + user.username + '\\' + file_name), 2)
            files.append({'type': define_type(file_name), 'name': file_name, 'size': file_size})
    except User.DoesNotExist:
        return error_500(request, msg='user does not exist')
    return render(request, 'mydir.html', {'user': user, 'list_files': files})


# страница Отправки файла
def send_view(request):
    try:
        user = User.objects.get(username=request.META['USERNAME'])
        form = SendForm()
    except User.DoesNotExist:
        return error_500(request, msg='user does not exist')
    return render(request, 'send_view.html', {'user': user, 'form': form, 'files': get_files_list(user.username)})


# страница Входящих файлов
def incoming_view(request):
    try:
        user = User.objects.get(username=request.META['USERNAME'])
        incoming_new = Record.objects.filter(receiver=user, status='Отправлено')
        incoming_old = Record.objects.filter(receiver=user).exclude(status='Отправлено')
    except User.DoesNotExist:
        return error_500(request, msg='user does not exist')
    return render(request, 'incoming_view.html', {'user': user, 'new_files': incoming_new, 'old_files': incoming_old})


# отправка файла
def send_file(request):
    if request.method == 'POST':
        form = SendForm(request.POST)
        if form.is_valid():
            filename = form.cleaned_data['filename']
            sender = User.objects.get(username=request.META['USERNAME'])
            receiver = User.objects.get(username=form.cleaned_data['receiver'])
            if get_files_list(receiver.username).__contains__(filename):
                request.session['alert'] = receiver.fio
                request.session.set_expiry(0)
                return redirect('/send_page')
            upload_date = datetime.now()
            size = os.path.getsize(dir_path + request.META['USERNAME'] + '\\' + filename)
            record = Record.objects.create(filename=filename,
                                           file_size=human_readable_size(size),
                                           sender=sender, receiver=receiver,
                                           status='Отправлено',
                                           upload_date=upload_date)
            destination = dir_path + 'exchange\\' + sender.username + '\\' + str(record.id) + '\\'
            os.system('mkdir ' + destination)
            fsrc = open(dir_path + sender.username + '\\' + filename, 'rb')
            fdst = open(destination + filename, 'ab')
            copyfileobj(fsrc, fdst, size)
            request.session['success'] = filename
            request.session.set_expiry(0)
            return redirect('/mydir')
    return error_500(request, msg='Can not send')


# Удаление файла
def delete_file(request):
    if request.method == 'POST':
        form = DeleteForm(request.POST)
        if form.is_valid():
            filename = form.cleaned_data['filename']
            os.remove(dir_path + request.META['USERNAME'] + "\\" + filename)
            return redirect('/mydir')
    return error_404(request, '')


# Переименование файла
def rename_file(request):
    if request.method == 'POST':
        form = RenameForm(request.POST)
        if form.is_valid():
            old_name = dir_path + os.getlogin() + "\\" + form.cleaned_data['old_name']
            new_name = dir_path + os.getlogin() + "\\" + form.cleaned_data['new_name']
            os.rename(old_name, new_name)
            return redirect('/mydir')
    return error_404(request, '')


# ошибка 404 - страница не найдена
def error_404(request, exception):
    return render(request, '404.html', status=404)


# ошибка 500 - сервер не работает
def error_500(request, *args, msg=''):
    return render(request, '500.html', {'msg': msg}, status=500)
