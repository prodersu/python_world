from django import forms
from .models import User
from .functions import *
import os


class DeleteForm(forms.Form):
    filename = forms.CharField(max_length=100)


class RenameForm(forms.Form):
    old_name = forms.CharField(max_length=100)
    new_name = forms.CharField(max_length=100, min_length=1)


class SendForm(forms.Form):
    user = User.objects.get(username=os.getlogin())
    files = []
    for file in get_files_list(user.username):
        if os.path.getsize(dir_path + user.username + '\\' + file) < 25 * 1024 * 1024:
            files.append((file, file))
    FILES_CHOICES = tuple(files)
    users_db = User.objects.exclude(username=user.username)
    users = []
    for user in users_db:
        users.append((user.username, user.fio))
    USERS_CHOICES = tuple(users)
    filename = forms.ChoiceField(choices=FILES_CHOICES, label='Выберите файл',
                                 widget=forms.Select(attrs={'class': 'form-select my-3'}))
    receiver = forms.ChoiceField(choices=USERS_CHOICES, label='Выберите получателя',
                                 widget=forms.Select(attrs={'class': 'form-select my-3'}))

