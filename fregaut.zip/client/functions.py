import os


dir_path = r'E:\\fregaut\\'


# преобразование размера файла в удобный формат
def human_readable_size(size, decimal_places=2):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024.0 or unit == 'PiB':
            break
        size /= 1024.0
    return f"{size:.{decimal_places}f} {unit}"


# определение типа файла
def define_type(filepath):
    extension = filepath.split('.')[-1]
    f_type = "Unknown"
    match extension:
        case 'txt':
            f_type = 'txt'
        case 'doc' | 'docx':
            f_type = 'ms-word'
        case 'xls' | 'xlsx':
            f_type = 'ms-excel'
        case 'ppt' | 'pptx':
            f_type = 'powerpoint'
        case 'rar' | 'zip' | 'tar' | 'gzip' | '7z':
            f_type = 'archive'
        case 'png' | 'jpg' | 'jpeg' | 'bmp':
            f_type = 'image'
        case 'pdf':
            f_type = 'pdf'
        case 'exe':
            f_type = 'exe'
    return f_type


# получить список файлов в директории
def get_files_list(username):
    files_list = []
    for path in os.listdir(dir_path + username):
        if os.path.isfile(os.path.join(dir_path + username, path)) and not path.startswith('~'):
            files_list.append(path)
    return files_list


def copyfileobj(fsrc, fdst, f_length, length=0):
    try:
        # check for optimisation opportunity
        if "b" in fsrc.mode and "b" in fdst.mode and fsrc.readinto:
            return _copyfileobj_readinto(fsrc, fdst, f_length, length)
    except AttributeError:
        print('one or both file objects do not support a .mode or .readinto attribute')
        pass

    if not length:
        length = 1024 * 1024

    fsrc_read = fsrc.read
    fdst_write = fdst.write

    copied = 0
    while True:
        buf = fsrc_read(length)
        if not buf:
            break
        fdst_write(buf)
        copied += len(buf)
        print(copied * 100 / f_length)


# differs from shutil.COPY_BUFSIZE on platforms != Windows
READINTO_BUFSIZE = 1024 * 1024


def _copyfileobj_readinto(fsrc, fdst, f_length, length=0):
    """readinto()/memoryview() based variant of copyfileobj().
    *fsrc* must support readinto() method and both files must be
    open in binary mode.
    """
    fsrc_readinto = fsrc.readinto
    fdst_write = fdst.write
    if not length:
        try:
            file_size = os.stat(fsrc.fileno()).st_size
        except OSError:
            file_size = READINTO_BUFSIZE
        length = min(file_size, READINTO_BUFSIZE)

    copied = 0
    with memoryview(bytearray(length)) as mv:
        i = 0
        while True:
            n = fsrc_readinto(mv)
            if not n:
                break
            elif n < length:
                with mv[:n] as smv:
                    fdst.write(smv)
            else:
                fdst_write(mv)
            copied += n
            i = i + 1
            percent = str(copied * 100 / f_length)
            print(str(i + 1) + '. ' + percent[:2] + "%")


