function openMenu(id){
    const btn_del = document.getElementById('btn-del'+id.toString());
    const btn_arrow = document.getElementById('btn-arrow'+id.toString());
    if(btn_arrow.classList.contains('d-none')){
        btn_arrow.classList.remove('d-none');
        btn_del.classList.add('d-none');
    }else{
        btn_arrow.classList.add('d-none');
        btn_del.classList.remove('d-none');
    }
}