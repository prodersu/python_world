from django.db import models


class User(models.Model):
    username = models.CharField('Учетная запись', max_length=10)
    fio = models.CharField('ФИО', max_length=20, null=True)


class Record(models.Model):
    filename = models.CharField(max_length=50, default=None)
    file_size = models.CharField(max_length=50, default=None)
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sender')
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='receiver')
    status = models.CharField(max_length=10)
    upload_date = models.DateTimeField(null=True)
    download_date = models.DateTimeField(null=True)